-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bookstore
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `author` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(200) DEFAULT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (1,'活着','余华',24.2,NULL,' 中国过去六十年所发生的一切灾难，都一一发生在福贵和他的家庭身上。接踵而至的打击或许令读者无从同情，但余华至真至诚的笔墨，已将福贵塑造成了一个存在的英雄。当这部沉重的小说结束时，活着的意志，是福贵身上不能被剥夺走的东西。'),(2,'浮生六记','沈复著，张佳玮译',22,NULL,'《浮生六记》俨如一块纯美的水晶，只见明莹，不见衬露明莹的颜色；只见精微，不见制作精微的痕迹。然而我自信这种说法不至于是溢美。想读这书的，必有能辨别的罢。'),(3,'围城','钱钟书',24.2,NULL,'凡是真正出色的文学作品，都具有一种抗理论分析力，任何自认为深透、精彩的理论都会在它们面前显得干瘪而又捉襟见肘。尽管钱锺书所著的《围城》本身并不朦胧，但我们读后的感觉仍是感觉大于思想，大于语言。'),(4,'我们三','杨绛',12.2,NULL,'一百零五岁的杨绛，以简洁而沉重的语言，回忆了女儿钱瑗、丈夫钱钟书，一家三口那些快乐而艰难、爱与痛的日子。故事证明：家庭是人生的庇护所。'),(5,'闲情偶寄','李渔',40.2,NULL,'《闲情偶寄》是一部讨论生活艺术的书。李渔极富创作思想，对每件东西都有新颖的议论。他所创作的器具中，有许多至今为人所用。');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-01  9:35:52
